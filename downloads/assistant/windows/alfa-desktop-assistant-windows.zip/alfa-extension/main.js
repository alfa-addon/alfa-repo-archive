/*!
 * Web Sniffer v0.0.0.3 (https://5ms.ru/sniffer/)
 * Copyright 2018, 5MS
 * Licensed under MIT (http://en.wikipedia.org/wiki/MIT_License)
 *
 * uglifyjs -b main.js > main.ug.js
 */

console.log('##Extension ' + chrome.runtime.id + ' activated! Main');

const MAIN_LOOP_REQUEST_NEW_DATA_TO_ASS_DESKTOP = 3000;
const MINIMUM_SECONDS_LENGTH_FOR_MEDIA = 300;
const EXTRA_TIME_FOR_OPENING_TAB = 1000;
var waawFoundAndReturnedResultWaitingQuit = false;
var foundServerWaaw = false;
var resultFoundList =[];

const CLIPBOARD_PREFIX_MEDIA_FOR_EXCHANGE = 'COMMMediafromChrome';
const CLIPBOARD_PREFIX_SOURCE_FOR_EXCHANGE = 'COMMSourcefromChrome';
const CLIPBOARD_PREFIX_ERROR = 'COMMErrorfromChrome';

var options = {
		limit: 1000,
		autoscroll: true,
		remove: false
	},
	rows = {
		tid: ['Tab'],
		rid: 'Request ID',
		type: ['Type'],
		time: ['Time'],
		status: ['Status'],
		method: ['Method'],
		hostname: ['Hostname'],
		url: 'URL',
		request: 'Request Headers',
		response: 'Response Headers',
		contentType: 'Content-type',
		contentBody: 'Content'
	},
	values = {
		requests: {},
		requests_all: 0,
		requests_visible: 0,
		filters: []
	},
    pause = true;

function isServerWaaw(str) {
	if (str != null) {
		var url = str.toLowerCase();
		return (
			url.includes('https://waaw.tv') || url.includes('https://netu.tv') || url.includes('https://hqq.tv')
			||
			url.includes('http://waaw.tv') || url.includes('http://netu.tv') || url.includes('http://hqq.tv')
		) && (
			url.includes('embed_player') || url.includes('watch_video')
		);
	} else {
		return false;
	}
}

$(function() {
	var a;

	for (a in options) {
		if (typeof options[a] == 'boolean') {
			$('.settings input[name="' + a + '"]').attr('checked', options[a]);
		} else {
			$('.settings input[name="' + a + '"]').val(options[a]);
		}
	}

	$('.settings .link').bind('click', function() {

		var setting = $(this).parent(),
			bottom = 0;

		if (parseInt(setting.css('bottom')) == 0) {
			bottom = -setting.height();
		}

		setting.animate({bottom: bottom});

	}).trigger('click');

	$('.settings .pause').bind('click', function() {

	    var title = $(this).attr('title'),
            data = $(this).data('title');

        $(this).attr('title', data);
        $(this).data('title', title);

        pause = !pause;
	    $(this).toggleClass('glyphicon-pause glyphicon-play');
	});

	$('.settings .trash').bind('click', function() {

		$('.req').remove();

		$('.filter.fixed').trigger('size');

		$(window).scrollTop(0);

		$('.settings .count').html( '0' );
	});

	$('.settings').bind('refresh', function() {

		var style = '';

		$('.filter-rows input[type="checkbox"]:not(:checked)', this).each(function() {

			style += '.filter-' + $(this).attr('name') + ' {display: none !important;}';
			style += '.req > .' + $(this).attr('name') + ' {display: none !important;}';

		});

		$('style#settings').html(style);

		$('.filter.fixed').trigger('size');
	});


	$('[name="limit"]')
		.bind('keypress', function(e) {

			var key = window.event ? e.keyCode : e.which;

			if (e.keyCode == 8 || e.keyCode == 46
				|| e.keyCode == 37 || e.keyCode == 39) {
				return true;
			}
			else if ( key < 48 || key > 57 ) {

				return false;
			}
			return true;

		}).bind('change', function() {

			options['limit'] = parseInt($(this).val());
		});


/*	$('[name="autoscroll"]').bind('click', function() {

		options['autoscroll'] = $(this).is(':checked');
	});*/

	$('[type="checkbox"]').bind('click', function() {

		options[ $(this).attr('name') ] = $(this).is(':checked');
	});



	$('.dropdown-toggle').dropdown();

	var filter = $('.filter');

	for (a in rows) {

		$('.filter-rows').append(
			$('<label/>')
				.addClass('control-label col-lg-1 checkbox')
				.append(
					$('<input/>')
						.attr({
							'type': 'checkbox',
							'name': a,
							'value': '1',
							'checked': true
						})
						.bind('click', function() {

							$('.settings').trigger('refresh');
						})
				)
				.append( typeof rows[a] == 'object' ? rows[a][0] : rows[a] )
		);


		filter.append(
			$('<div/>')
				.addClass('filter-' + a)
		);

		if (typeof rows[a] == 'object') {

			$('.filter-' + a).html(

				$('<div/>')
					.addClass('btn-group')
					.append(
						$('<button/>')
							.addClass('btn btn-sm btn-default dropdown-toggle')
							.attr({
								'type': 'button',
								'data-toggle': 'dropdown'
							})
							.append(
								$('<span/>').addClass('glyphicon glyphicon-filter')
							)
							.append(
								rows[a][0]
							)
					)
					.append(
						$('<ul/>')
							.addClass('dropdown-menu dropdown-menu-form')
							.attr('role', 'menu')
							.attr('id', a)
							.append(
								$('<li/>')
									.addClass('checkbox')
									.append(
										$('<label/>')
											.append(
												$('<input/>')
													.attr({
														'type': 'checkbox',
														'name': 'all',
														'val': 'all',
														'checked': true
													})
											)
											.append('All')
											.append(
												$('<span/>')
													.attr('id', 'badge-' + a)
													.addClass('badge badge-empty badge-right')
													.html('0')

										)
									)
							)
					)
			);


		} else {

			$('.filter-' + a).html(

				$('<div/>')
					.addClass('btn-group')
					.append(
						$('<span/>')
							.addClass('btn btn-sm disabled')
							.attr({
								'type': 'button',
								'data-toggle': 'dropdown'
							})
							.append(
								rows[a]
							)
					)
			);
		}


	}

	filter.append(
		$('<div/>')
			.addClass('filter-empty')
	);


	$(document).on('click', '.dropdown-menu.dropdown-menu-form', function(e) {
		e.stopPropagation();
	});


	$(document).on('click', 'input[name="filter"]', function() {

		var block = $(this).parents('.dropdown-menu'),
			button = block.prev(),
			sel = '.' + $(this).val();

		$('input[name="all"]', block).prop('checked',
			$('input[name="filter"]', block).length == $('input[name="filter"]:checked', block).length
		);

		var checked = $(this).prop('checked');

		if ($('input[name="all"]', block).prop('checked')) {

			$('input[name="filter"]', block).each(function() {

				var a = values.filters.indexOf( sel );

				if (a >= 0)
					values.filters.splice(a, 1);

			});

			button.removeClass('active');

		} else {

			button.addClass('active');

			if (checked) {

				var a = values.filters.indexOf( sel );

				if (a >= 0)
					values.filters.splice(a, 1);

			} else {
				values.filters.push( sel );
			}
		}

		values.filters = $.grep(values.filters, function(v, k){
		    return $.inArray(v, values.filters) === k;
		});

		if (values.filters.length > 0) {

			$('.req').show().filter( values.filters.join(", ") ).hide();

		} else {
			$('.req').show();
		}

		filter_fixed.trigger('size');
	});


	$(document).on('click', 'input[name="all"]', function() {

		var block = $(this).parents('.dropdown-menu');

		$('input[name="filter"]', block).trigger('click');

	});


	var filter_fixed = filter.clone();

	filter.after( filter_fixed );
	filter_fixed.addClass('fixed');
	filter_fixed.bind('size', function() {

		$(this).children().each(function(k) {

			$(this).width( filter.children('div:eq(' + k + ')').width() || 'auto' );
		});

		counts();
	});

	$(window).on({
		scroll: function() {

			filter_fixed.css('left', -$(this).scrollLeft());
		},
		load: function() {

			filter_fixed.trigger('size');
		},
		resize: function() {

			filter_fixed.trigger('size');
		}
	});


	$(document).on('click', '.tid.open span', function(e) {

		var tabId = parseInt($(this).html()),
			frameId = parseInt($(this).attr('id'));

		chrome.tabs.update(tabId, {selected: true});

		chrome.windows.update(frameId, {focused: true});

		e.stopPropagation();

	});

	$(document).on('click', '.req', function() {

		$(this).toggleClass('selected');
	});

	$(document).on('click', '.tid.open b', function(e) {

		var tabId = parseInt($(this).attr('id'));

		if (confirm('Close tab?')) {

			chrome.tabs.remove(tabId);
		}

		e.stopPropagation();
	});

	$(document).on('click', '[readonly]', function(e) {

		$(this).focus().select();

		e.stopPropagation();
	});

	$(document).on('click', '[rel="popover"]', function(e) {

//		$('.popover').removeClass('in');

		if ($(this).data('original-title') != undefined) {

//			alert(1);

//			$(this).popover('toggle');

		} else {

			$(this).popover({
				html: true,
				content: $(this).next().html()
			}).popover('show');

		}

		$(this).next().css('top', 0);

		e.stopPropagation();
	});

	var disableScroll = function(e){

		if($(e.srcElement).parents('.popover')) {

//			window.onscroll = function () { window.scrollTo(0, 0); };

		} else {

			e.preventDefault();
		}

	};


	$(document).on('mouseover', '.popover-content', function() {

		$(window).on('mousewheel', disableScroll);

	})
	.on('mouseout', '.popover-content', function() {

		$(window).off('mousewheel', disableScroll);
	});


//	events.focus: function(){ $(window).on('keydown', disableScroll); }
//	events.blur: function(){ $(window).off('keydown', disableScroll); }

	$('html').on('click', function (e) {
		$('[data-original-title]').each(function () {
			if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
				$(this).popover('hide');
			}
		});
	});

	$(document).on('click', 'a', function(e) {

		e.stopPropagation();
	});
});

function parse_url(url) {
	var parser = document.createElement('a');
	parser.href = url;

/*
	parser.protocol; // => "http:"
	parser.host;     // => "example.com:3000"
	parser.hostname; // => "example.com"
	parser.port;     // => "3000"
	parser.pathname; // => "/pathname/"
	parser.hash;     // => "#hash"
	parser.search;   // => "?search=test"
*/

	return parser;
}

function parse_domain(str) {
	var regex = /[^.]+.[^.]+$/gi;
	return regex.exec( str.toString().toLowerCase() );
}

function parse_status(str) {
	var regex = /(\d{3})[\w\s.,-]*$/gi;
	return regex.exec( str.toString() );
}

var makeCRCTable = function(){
    var c;
    var crcTable = [];
    for(var n =0; n < 256; n++){
        c = n;
        for(var k =0; k < 8; k++){
            c = ((c&1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1));
        }
        crcTable[n] = c;
    }
    return crcTable;
};

String.prototype.crc32 = function() {
    var crcTable = window.crcTable || (window.crcTable = makeCRCTable());
    var crc = 0 ^ (-1);

    for (var i = 0; i < this.length; i++ ) {
        crc = (crc >>> 8) ^ crcTable[(crc ^ this.charCodeAt(i)) & 0xFF];
    }

    return (crc ^ (-1)) >>> 0;
};


function hash(str) {
	return str.toString().toLowerCase().replace(/[^0-9a-z]/g, '');
}

function object_to_table(data, s) {

	s = s || '';

	if (typeof data == "object") {

		s += '<table class="table table-bordered">';

		for (var a in data) {

			s += '<tr><td><input type="text" class="form-control right" value="' + replaceAll(a) + '" title="' + a.length + '" readonly></td><td>';

			if (typeof data[a] == "object") {

				s += object_to_table(data[a]);

			} else {

				s += '<input type="text" class="form-control" value="' + replaceAll(data[a]) + '" title="' + data[a].length + '" readonly>';
			}

			s += '</td></tr>';
		}

		s += '</table>';
	}

	return s;
}

function body_to_table(data, s) {

	s = s || '';

	if (typeof data == "object") {

		s += '<table class="table table-bordered">';

		for (var a in data) {

			if (a == 'formData') {
				s = body_to_table(data[a]);
			} else {
				s += '<tr><td><input type="text" class="form-control right" value="' + replaceAll(a) + '" title="' + a.length + '" readonly></td><td>';

				if (typeof data[a] == "object") {

					if (data[a].length > 0) {
						for (var b in data[a]) {
							if (b > 0) {
								s += '<div class="hr"></div>';
							}
                            s += '<input type="text" class="form-control" value="' + replaceAll(data[a][b]) + '" title="' + data[a][b].length + '" readonly>';
						}

					} else {
						s += body_to_table(data[a]);
					}

				} else {
					s += '<input type="text" class="form-control" value="' + replaceAll(data[a]) + '" title="' + data[a].length + '" readonly>';
				}

				s += '</td></tr>';
			}
		}

		s += '</table>';
	}

	return s;
}

function header_to_table(data, s) {

	s = '<table class="table table-bordered">';

	for (var i = 0; i < data.length; i++) {

		s += '<tr>';

		for (var a in data[i]) {

			s += '<td><input type="text" class="form-control' + (a == 'name' ? ' right' : '') + '" value="' + replaceAll(data[i][a]) + '" title="' + data[i][a].length + '" readonly></td>';
		}

		s += '</tr>';

	}

	s += '</table>';

	return s;
}

function parse_search(search) {

    var params = {};
    var e,
        a = /\+/g,  // Regex for replacing addition symbol with a space
        r = /([^&;=]+)=?([^&;]*)/g,
//        d = function (s) { return decodeURIComponent(s.replace(a, " ")); },
        d = function (s) { return (s.replace(a, " ")); },
        q = search.substring(1);

    while (e = r.exec(q))
       params[d(e[1])] = d(e[2]);

    return params;
}



function filter_add_item(filter, id, str) {

	var f = $('.filter-' + filter + ':last'),
		ul = $('ul', f),
		badge,
		i;

	if (!$('#' + filter + '-' + id, f).is(':input')) {

		if ($('li', ul).length == 1) {

			ul.append(
				$('<li/>').addClass('divider')
			);
		}

		ul.append(
			$('<li/>')
				.addClass('checkbox')
				.append(
					$('<label/>')
						.append(
							$('<input/>')
								.attr({
									'type': 'checkbox',
									'name': 'filter',
									'value': filter + '-' + id,
									'id': filter + '-' + id,
									'checked': true
								})
						)
						.append( str )
						.append(
							$('<span/>')
								.attr('id', 'badge-' + filter + '-' + id)
								.addClass('badge badge-right')
								.html('1')
						)
				)
		);

		badge = $('#badge-' + filter, ul);
		i = parseInt( badge.html() );
		badge.html( i + 1 );

	} else {

		badge = $('#badge-' + filter + '-' + id, ul);
		i = parseInt( badge.html() );
		badge.html( i + 1 );
	}
}


function counts() {

	$('.settings .count-all')
				.html( values.requests_visible );

	if (values.filters.length > 0) {

		$('.settings .count-all')
			.show();

		$('.settings .count')
			.html($('.req:visible').length);

	} else {

		$('.settings .count')
			.html( values.requests_visible );

		$('.count-all').hide();
	}
}

chrome.tabs.onRemoved.addListener(function(tabId) {
	if (options.remove) {

		var tabs = $('.tid-' + tabId);

		values.requests_all -= tabs.length;
		values.requests_visible -= tabs.length;

		tabs.remove();

		counts();

	} else {

		$('.tid-' + tabId + ' > .open').removeClass('open');
	}
});

chrome.runtime.onConnect.addListener(function(port) {
	//console.log('##Extension added Listener onConnect for port ', port);
	port.onMessage.addListener(function(Message) {
		//console.log('##Extension trigered Listener onMessage for message', Message);
	    if (pause) {
	        return false;
        };

		var url = parse_url(Message.Details.url);
		var _url = url.hostname + url.pathname + url.search;

		// Not interesting to share with Assistant Desktop
		if (!isAllowedSourceByUrl(_url) && !isAllowedResourceByUrl(_url)) {
			return false;
		}

		// console.log('Message.Type', Message.Type);

		if (Message.Type == 'Completed') {
			console.log(new Date().getTime() + '>>TAB Completed>', Message);

		}
		if (Message.Type == 'BodyContent') {
			if (Message.Details && Message.Details.url && Message.Details.contentUpdated == true) {
				bodyContentLoadedNotified(Message.Details.url)
			}
			return sendInfoToAssDesktop(Message.Details);
		}

		var tr_class = 'req' + Message.Details.requestId,
			id = tr_class + '_' + _url.crc32(),
			tr = $('#' + id);

		if (!tr.is('div')) {

			if (values.requests[id] == undefined) {

				values.requests[id] = true;
				values.requests_all++;
				values.requests_visible++;

				tr = $('<div/>')
					.addClass('req ' + tr_class)
					.attr('id', id)
					.css('display', 'none');

				for (var a in rows) {

					tr.append(
						$('<div/>')
							.addClass(a)
					);

				}

				tr.addClass('tid-' + Message.Details.tabId);

				$('.rid', tr).html(Message.Details.requestId);

				var params = parse_search(url.search);

				var _type = hash(Message.Details.type);
				filter_add_item('type', _type, Message.Details.type);

				tr.addClass('type-' + _type);
				$('.type', tr).html(Message.Details.type);

				var hostname = url.hostname;
				var domain = parse_domain(url.hostname);
				var _hostname = hash(url.hostname);

				if (domain != url.hostname) {

					_hostname = hash(domain);
					hostname = domain;
				}

				filter_add_item('hostname', _hostname, hostname);

				tr.addClass('hostname-' + _hostname);

				$('.hostname', tr).html(url.hostname);

				//$('.req' + 375).find("table").find("tr") td td
				//console.error(Message.Details.requestHeaders);

				$('.url', tr)
					.append(
						$('<a/>')
							.addClass('glyphicon glyphicon-new-window')
							.attr({
								'href': '#',
								'onclick': "console.log('" + Message.Details.url + "'); return false;",
								'target': '_blank'
							})
					)
					.append(
						$('<input/>')
							.attr('readonly', true)
							.val(url.pathname)
					)
					.append(
						$('<span/>')
							.addClass('glyphicon glyphicon-list' + (Object.keys(params).length == 0 ? ' hidden' : ''))
							.attr({
								'rel': 'popover',
								'title': 'GET Params'
							})
							.data('placement', 'left')
							.html(
								$('<span/>').html(Object.keys(params).length )
							)
					)
					.append(
						$('<div/>')
							.addClass('hidden')
							.html(
								object_to_table(params)
							)
					);


				var time = new Date(Message.Details.timeStamp).toTimeString().slice(0, 8);
				$('.time', tr)
					.html(time)
					.append('<span></span>');


				if ($('.' + tr_class).is('div')) {

					$('.' + tr_class + ':first').before(tr);

				} else {

					$('.filter.fixed').after(tr);
				}

				values.requests[id] = undefined;

				if (values.requests_visible > options.limit) {

					$('.req:last').remove();

					values.requests_visible--;
				}

				if (!options['autoscroll']) {

					$(window).scrollTop( $(window).scrollTop() + $('.req:last').height() );
				}


				counts();

			}
		}

		if (Message.Type == 'Request') {
			var body = '';

			if (Message.Details.requestBody != undefined) {
				body = body_to_table(Message.Details.requestBody);
			}

			var _tid = hash(Message.Details.tabId);
			filter_add_item('tid', _tid, Message.Details.tabId);

			tr.addClass('tid-' + _tid);

			if (Message.TabInfo != undefined) {

				if ($('.tid', tr).html() == '') {

					$('.tid', tr)
						.addClass('open')
						.append(
							$('<b/>')
								.attr({
									'id': Message.Details.tabId,
									'title': 'Close tab'
								})
						)
						.append(
							$('<span/>')
								.attr({
									'id': Message.TabInfo.windowId,
									'title': Message.TabInfo.title
								})
								.html(Message.Details.tabId)
						);
				}


			} else {

				$('.tid', tr)
					.append(
						$('<span/>')
							.html(Message.Details.tabId)
					);

			}


			if ($('.status', tr).html() == '') {
				$('.status', tr)
					.append('loading...');
			}

			var _method = hash(Message.Details.method);
			filter_add_item('method', _method, Message.Details.method);

			tr.addClass('method-' + _method);

			$('.method', tr)
				.html(Message.Details.method)
				.append(
					body != '' ? $('<span/>').append(
										$('<span/>')
											.append(
												$('<span/>')
													.addClass('glyphicon glyphicon-list')
													.attr({
														'rel': 'popover',
														'title': 'POST Data'
													})
													.data('placement', 'left')
											)
											.append(
												$('<div/>')
													.addClass('hidden')
													.html(
														body
													)
											)
									)
						: ''
				);


		} else if (Message.Type == 'SendHeaders') {
			$('.request', tr)
				.append(
					$('<span/>')
						.addClass('glyphicon glyphicon-log-in')
						.attr({
							'rel': 'popover',
							'title': 'Request Headers'
						})
						.data('placement', 'left')
						.html(
							$('<span/>').html( Message.Details.requestHeaders.length )
						)
				)
				.append(
					$('<div/>')
						.addClass('hidden')
						.html(
							header_to_table(Message.Details.requestHeaders)
						)
				)

		} else if (Message.Type == 'Received') {
			$('.response', tr)
				.append(
					$('<span/>')
						.addClass('glyphicon glyphicon-log-out')
						.attr({
							'rel': 'popover',
							'title': 'Response Headers'
						})
						.data('placement', 'left')
						.html(
							$('<span/>').html( Message.Details.responseHeaders.length )
						)
				)
				.append(
					$('<div/>')
						.addClass('hidden')
						.html(
							header_to_table(Message.Details.responseHeaders)
						)
				)

			var _ct = "contentType_" + hash(Message.Details.requestId);
			var contentType = "";
			for (var i = 0; i < Message.Details.responseHeaders.length; i++) {
				if (Message.Details.responseHeaders[i].name == 'content-type') {
					contentType = Message.Details.responseHeaders[i].value;
					break;
				}
			}
			$('.contentType', tr).html(contentType);
			/*filter_add_item('contentType', _ct, contentType + '!');
			tr.addClass('ct-' + _ct);
			$('.ct', tr).html(contentType + "!!");*/

			//TODO Pdte! Cuidado que habilita el body del debug!!! https://stackoverflow.com/questions/18534771/chrome-extension-how-to-get-http-response-body
			var _ct = "contentBody_" + hash(Message.Details.requestId);
			var contentBody = "";
			for (var i = 0; i < Message.Details.responseHeaders.length; i++) {
				if (Message.Details.responseHeaders[i].name == '???') {
					contentBody = Message.Details.responseHeaders[i].value;
					break;
				}
			}
			$('.contentBody', tr).html(contentBody);

			//if (!waawFoundAndReturnedResultWaitingQuit) {
				var url = Message.Details.url;
				if (url != null) {
					url = url.trim();
				}
				//Check if Waaw/Netu/Hqq
				if (!foundServerWaaw && isServerWaaw(url)) {
					foundServerWaaw = true;
					console.warn('Found Server: ', url);
				}
				else if (foundServerWaaw && url.includes('secip') && !url.includes('frag') && !url.includes('Frag')) {
					console.warn('Found Media: ', url);

					$.post( "http://localhost:47774/Only_access_for_developer___MANAGEMENT/alfa_server_helper__get_media_length.php",
						{
							URL: url
						},
						function(data) {
						try {
							console.info('##Video "' + url + '" has a length of: ' + data);

							if (data != null && data != '') {
								var _splitted = data.split('.');
								var splitted = _splitted[0].split(',');
								var nmb = Number(splitted[0].trim());
								if (nmb != null && nmb != '' && !isNaN(nmb) && nmb >= MINIMUM_SECONDS_LENGTH_FOR_MEDIA) {
									const result = {
										"URL": url,
										"Protocol": 'GET',
										"Request Headers": {
										},
										"duration": nmb
									};
									resultFoundList.push(result);
									copyToClipboard(CLIPBOARD_PREFIX_MEDIA_FOR_EXCHANGE + JSON.stringify((resultFoundList)));
									console.error('We can all stop and coming back to Electron with URL ' + url + ' having a duration of ' + nmb + ' seconds or ' + getMinutes(nmb) + ' minutes');
									waawFoundAndReturnedResultWaitingQuit = true;
								}
							}
						} catch (exc) {
							//Not a right video
							console.info('##Not a right video');
						}
					});
				}
			//}

		/*} else if (Message.Type == 'ResponseBodyReceived') {
		 	console.log('>>BodyReceived>', Message);*/

		} else if (Message.Type == 'ErrorOccurred') {
			var errMessage = (Message.Details.error || 'Error!').replace(':', '').replace(':', '');

			filter_add_item('status', errMessage, errMessage);
			tr.addClass('status-' + errMessage);

			$('.status', tr).html(errMessage);

		}

		if (Message.Details.fromCache) {
			$('.type', tr)
					.append(' (cache)');
		}

		if (Message.Details.statusLine != undefined) {

			var _status = parse_status(Message.Details.statusLine);

			if (_status != null) {
				filter_add_item('status', _status[1], _status[0]);
				tr.addClass('status-' + _status[1]);

				$('.status', tr).html(_status[1]);

			} else {
				$('.status', tr).html('??? - ' + Message.Details.statusLine);
			}
		}

		if ($('.time', tr).attr('stamp') == undefined) {

			$('.time', tr).attr('stamp', Message.Details.timeStamp);

		} else {

			var ms = parseInt(Message.Details.timeStamp - $('.time', tr).attr('stamp'));

			if (ms < 0) {
				$('.time', tr).attr('stamp', Message.Details.timeStamp);
				ms *= -1;
			}

			var sec = parseInt(ms / 1000);

			tr.addClass('time-' + sec);

			$('.time', tr)
				.attr('class','time time-' + sec);

			$('.time > span', tr)
				.html('(' + ms + 'ms)');

			var _time = hash(sec);
			filter_add_item('time', _time, sec);
		}

		if (tr.is( values.filters.join(", ") )) {
			tr.hide();
		} else {
			tr.show();
		}


		values.requests[id] = undefined;

		$('.filter.fixed').trigger('size');

	});

});

// chrome.runtime.onMessage.addListener(
// 	function(message, callback) {
// 		console.log('#changeColor!', message)
// 		/*if (message == "changeColor"){
// 			chrome.tabs.executeScript({
// 				code: 'document.body.style.backgroundColor="orange"'
// 			});
// 		}*/
// });
chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
	console.log("Received %o from %o, frame", msg, sender.tab, sender.frameId);

	if (msg && msg.Type == 'BodyContent') {
		if (msg.Details && msg.Details.url && msg.Details.contentUpdated == true) {
			bodyContentLoadedNotified(msg.Details.url)
		}
		sendInfoToAssDesktop(msg.Details);

	}

	if (msg && msg.source && isServerWaaw(msg.url)) {
		console.error(msg.vjsModalDialogContent);
		sendResponse("Gotcha!");

		var errorMessage = null;
		var msg_source_lowercase = msg.source.toLowerCase();
		if (
			msg_source_lowercase.includes('copyright')
			&&
			msg_source_lowercase.includes('blocked')
			&&
			msg_source_lowercase.includes('violation')
		) {
			errorMessage = 'Copyright blocked violation (I)';
		}
		else if (
			msg_source_lowercase.includes('video not working')
			&&
			msg_source_lowercase.includes('deleted')
			&&
			msg_source_lowercase.includes(' due to copyright')
		) {
			errorMessage = 'Copyright blocked violation (II)';
		}
		else if (
			msg_source_lowercase.includes('access denied')
			&&
			msg_source_lowercase.includes('banned')
			&&
			msg_source_lowercase.includes('cloudflare')
		) {
			errorMessage = 'Access denied - Banned IP or IP range by Cloudflare';
		}
		else if (
			msg_source_lowercase.includes('access denied')
			&&
			msg_source_lowercase.includes('banned')
		) {
			errorMessage = 'Access denied  - Banned';
		}

		//Detect too short "openpopplayerin('VFhPRPHg09Hk',event);" The key need at least 32 characters
		else if (
			msg_source_lowercase.includes('<iframe src="')
			&&
			containsRegex(msg.source, 'iframe src="\\/.\\/[a-zA-Z0-9]{32,}\\?').length == 0
		) {
			errorMessage = 'Access denied - Video not found';
		}

		if (errorMessage != null) {
			console.error('##Error: ' + errorMessage);
			copyToClipboard(CLIPBOARD_PREFIX_ERROR + errorMessage);
		}
	}
});

function containsRegex(str, regex) {
	var myRe = new RegExp(regex, 'g');
	arr = myRe.exec(str);	// return array
	if (arr == null) {
		return [];
	} else {
		return arr;
	}
}
/*
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
	console.log("Message received from commFromSource: ", message, sender);
});*/


/***************************//***************************//***************************//***************************//***************************/

//window.open('chrome-extension://ndfgffclcpdbgghfgkmooklaendohaef/index.html')
//window.open('https://yahoo.com')
/*chrome.tabs.query({ currentWindow: true, active: false }, function (tabs) {

});*/

function resetDashboard() {
	$('.req').remove();

	$('.filter.fixed').trigger('size');

	$(window).scrollTop(0);

	$('.settings .count').html( '0' );
}

var callerParams = {};
var lastDesktopId = '';
var closeTabsCountdown;

function terminateAll() {
	try {
		if (engineTimeout) {
			clearTimeout(engineTimeout);
		}
	} catch (e) {}
}

function manageAnswer(callerParamsBase64) {
	// console.log("Alfa Extension Webserver: Received answer from Alfa Desktop");	// second success
	try {
		if (!callerParamsBase64) {
			pause = true;
			if (lastDesktopId && lastDesktopId.length > 0) {
				cancelCountdown();
				closeOtherTabs();
				/*if (!callerParams.urlParamDEBUG) {
					resetDashboard();
				}*/
				console.log("Alfa Extension Webserver: Assistant Desktop has sent to the user. So countdown was cancelled");
			}
			lastDesktopId = '';

		} else {
			callerParams = JSON.parse(atob(callerParamsBase64));
			// Decode used params
			// console.log('callerParams', callerParams);
			if (lastDesktopId != callerParams.timestamp) {
				lastDesktopId = callerParams.timestamp;
				pause = true;
				cancelCountdown();
				closeOtherTabs();
				if (!callerParams.urlParamDEBUG) {
					resetDashboard();
				}

				console.log("Alfa Extension Webserver: Received new URL from Assistant Desktop");

				callerParams.action = (callerParams.action);
				if (callerParams.action == TpAction.TERMINATE) {
					terminateAll();
					manageAnswer(null);
					return;
				}
				callerParams.urlParamURL = atob(callerParams.urlParamURL);
				callerParams.urlParamDEBUG = (callerParams.urlParamDEBUG && callerParams.urlParamDEBUG == "true");
				callerParams.urlParamTIME = +(callerParams.urlParamTIME);
				callerParams.urlParamJSCode = +(callerParams.urlParamJSCode);
				callerParams.urlParamJSDirectCode = +(callerParams.urlParamJSDirectCode);
				callerParams.urlParamJSDirectCode2 = +(callerParams.urlParamJSDirectCode2);
				callerParams.urlParamExtraPostDelay = +(callerParams.urlParamExtraPostDelay);
				callerParams.MAX_TIME_WAITING_INJECTION = +(callerParams.MAX_TIME_WAITING_INJECTION);
				callerParams.returnWhenCookieNameFound = callerParams.returnWhenCookieNameFound;
				callerParams.urlParamHardReset = atob(callerParams.urlParamHardReset) == "true";
				callerParams.urlParamClearWebCache = atob(callerParams.urlParamClearWebCache) == "true";	// done on Assistant Desktop
				callerParams.urlParamRemoveAllCookies = atob(callerParams.urlParamRemoveAllCookies) == "true";	// Syntax: "url1|cookieName1|url2|cookieName2"  Example: https://btdig.com|cf_clearance
				if (callerParams.urlParamRemoveAllCookies || callerParams.urlParamHardReset || callerParams.urlParamClearWebCache) {
					removeAllCookies(DoTheJob);
				} else {
					DoTheJob();
				}

				function DoTheJob() {
					// Set cookies to share info with "background.js" and "contentScript.js" using method "watchMainCallerParams"
					document.cookie='callerParams=' + JSON.stringify(callerParams);

					// Load new window url
					if (callerParams.urlParamDEBUG) {
						// Show monitoring
						pause = false;
					} else {
						// Stop monitoring
						pause = true
						// Stop console output
						disableConsole();
					}

					//TODO Change to open tab with headers
					window.open(callerParams.urlParamURL);
					console.log("Alfa Extension Webserver: URL open in a new tab successfully: ", callerParams.urlParamURL);

					var countDown = callerParams.urlParamTIME + callerParams.urlParamExtraPostDelay + EXTRA_TIME_FOR_OPENING_TAB;
					if (callerParams.action == TpAction.GET_SOURCE_WHEN_TIMEOUT || callerParams.action == TpAction.GET_SOURCE_WHEN_PAGE_FINISHED || callerParams.action == TpAction.GET_URLS_WHEN_PAGE_FINISHED || callerParams.action == TpAction.GET_SOURCE_WHEN_PAGE_FINISHED_RUN_JS) {
						countDown += callerParams.MAX_TIME_WAITING_INJECTION
					}
					countDowndownFinishedAll(countDown)
				}
			}
		}
	} catch (e) {
		console.log("Alfa Extension Webserver: Error processing data returned from Alfa Desktop", e);
	}
}

function cancelCountdown() {
	try {
		if (closeTabsCountdown) {
			clearTimeout(closeTabsCountdown);
		}
	} catch (e) {}
}

function countDowndownFinishedAll(countDown) {
	console.log('Alfa Extension Webserver: Countdown for closing all tabs: ' + countDown + ' ms');
	cancelCountdown();
	if (callerParams && callerParams.timestamp) {
		closeTabsCountdown = setTimeout(() => {
			pause = true;
			cancelCountdown();
			closeOtherTabs();
			// resetDashboard();
			console.log('Alfa Extension Webserver: Countdown finished, closed all tabs');
			fetch('http://127.0.0.1:48886/INFO_FROM_CHROME_DESKTOP?headerFromChrome=' + btoa('EXTENSION_FINISHED_WORK') + '&cache=false&dataFromChrome=' + btoa(callerParams.timestamp)).then(function (response) {
				console.log('Notified by Assistant Desktop my countdown is finished');
			});
		}, countDown);
	}
}

function bodyContentLoadedNotified(url) {
	console.log('Alfa Extension Webserver: Body Content Loaded Notified');
	if (callerParams.urlParamURL == url && 	//TODO ¿Si cambia la URL (redirección o rebase interno) recibiré la URL correcta yo?
		(callerParams.action == TpAction.GET_SOURCE_WHEN_TIMEOUT || callerParams.action == TpAction.GET_SOURCE_WHEN_PAGE_FINISHED || callerParams.action == TpAction.GET_URLS_WHEN_PAGE_FINISHED || callerParams.action == TpAction.GET_SOURCE_WHEN_PAGE_FINISHED_RUN_JS)) {
		var countDown = callerParams.urlParamTIME + callerParams.urlParamExtraPostDelay;
		countDowndownFinishedAll(countDown);
	}
}

/*
* Get information about current status of Alfa Assistant Desktop
*/
function getAlfaDesktopCurrentStatus() {
	fetch('http://127.0.0.1:48886/INFO_FROM_CHROME_DESKTOP?headerFromChrome=' + btoa('EXTENSION_GET_CURRENT_STATUS') + '&cache=false').then(function (response) {
		return response.text();	//or response.json()

	}).then(function (data) {
		manageAnswer(data);

		setTimeout(() => {
			getAlfaDesktopCurrentStatus();
		}, 3000);

	}).catch(function (err) {
		console.warn('Something went wrong.', err);

		setTimeout(() => {
			getAlfaDesktopCurrentStatus();
		}, MAIN_LOOP_REQUEST_NEW_DATA_TO_ASS_DESKTOP);
	});
}

engineTimeout = setTimeout(() => {
	getAlfaDesktopCurrentStatus();
}, 1000);


