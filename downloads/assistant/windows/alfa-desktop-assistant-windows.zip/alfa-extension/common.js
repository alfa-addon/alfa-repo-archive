const TpAction = {
    GET_SOURCE_WHEN_PAGE_FINISHED: 'GET_SOURCE_WHEN_PAGE_FINISHED',
    GET_SOURCE_WHEN_TIMEOUT: 'GET_SOURCE_WHEN_TIMEOUT',
    GET_SOURCE_WHEN_PAGE_FINISHED_RUN_JS: 'GET_SOURCE_WHEN_PAGE_FINISHED_RUN_JS',
    GET_URLS_WHEN_PAGE_FINISHED: 'GET_URLS_WHEN_PAGE_FINISHED',
    PING: 'PING',
    INTERNAL_PING: 'INTERNAL_PING',
    QUIT: 'QUIT',
    TERMINATE: 'TERMINATE',
    UPDATE: 'UPDATE',
    INFO_FROM_CHROME_DESKTOP: 'INFO_FROM_CHROME_DESKTOP',
    OPEN_BINARY: 'OPEN_BINARY',
    GET_BINARY_STATUS: 'GET_BINARY_STATUS',
    KILL_BINARY: 'KILL_BINARY',
    GET_BINARY_LIST: 'GET_BINARY_LIST'
}

const copyToClipboard = str => {
    const el = document.createElement('textarea');
    el.value = str;
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);
};

function getMinutes(seconds) {
    return (Math.round(seconds / 60 * 100) / 100).toFixed(2);
}

function replaceAll(s) {
    if (typeof s != 'string') {
        s = JSON.stringify(s);
    }
    return s.replace(/"/g, '&quot;').replace(/</g, '&lt;');
}

function getCurrentTab() {
    chrome.tabs.getCurrent(function (tab) {
        // chrome.tabs.remove(tab.id, function() { });
    });
}

function closeOtherTabs() {
    chrome.tabs.query({}, function (tabs) {
        // Exclude non necessary tabs
        for (let tab of tabs) {
            if (!tab.url.includes("alfa-chrome-app-wnd") && !tab.url.includes("chrome-extension://")  && !tab.url.includes("chrome://") && !tab.url.includes("devtools://")) {
                chrome.tabs.remove(tab.id, function () {
                });
            }
        }
    });
    /*chrome.tabs.getAllInWindow(null, function(tabs){
        for (var i = 0; i < tabs.length; i++) {
            chrome.tabs.sendRequest(tabs[i].id, { action: "xxx" });
        }
    });*/
}

function disableConsole() {
    console.log = function () {
    }
    console.info = function () {
    }
    console.warn = function () {
    }
    console.debug = function () {
    }
    console.error = function () {
    }
    console.clear = () => {
    }
}

function sendDatataMain(details, allCookies) {
    setTimeout(() => {
        var url = details.url;
        var body = details.body ? unescape(encodeURIComponent(details.body)) : '';
        var bodyLength = details.body ? details.body.length : 0;
        var method = details.method ? details.method : '';	//TODO
        var headers = details.headers ? details.headers : '';	//TODO
        var strBody;
        try {
            strBody = btoa(body)
        } catch (e) {
            strBody = btoa(JSON.stringify(body))
        }
        var json = btoa(
            btoa(url) + '|' +
            strBody + '|' +
            method + '|' +
            (headers ? btoa(JSON.stringify(headers)) : '') + '|' +
            (allCookies ? btoa(allCookies.join('{|}')) : '') +
            '|extraDummy'
        )
        console.log("SendInfoToAssDesktop: Sending 'BodyContent' to Assistant Desktop...", url, 'Body length', bodyLength);
        let bodyContentUrlToDesktop = 'http://localhost:48886/INFO_FROM_CHROME_DESKTOP?headerFromChrome=' + btoa('URL_BODY_METHOD_HEADERS_COOKIES') + '&cache=false';
        // console.log('#headerFromChrome URL', details.url);
        // console.log('#headerFromChrome Body', details.body[0]);
        console.log("SendInfoToAssDesktop URL...", bodyContentUrlToDesktop);
        fetch(bodyContentUrlToDesktop, {
            method: 'POST',
            body: 'dataFromChrome=' + json  // raw body
        }).then(response => {
            return response;
        }).then(data => {
            console.log('SendInfoToAssDesktop: Done', data);
        }).catch(err => {
            console.error('SendInfoToAssDesktop: Something went wrong.', err);
        });
    }, 0);
}

function sendInfoToAssDesktop(details) {
    // if (isAllowedSourceByUrl(details.url) || isAllowedResourceByUrl(details.url)) {
        try {
            if (isAllowedSourceByUrl(details.url) || details.targetCookieFound) {
                // The important to receive in the other side is the name and value. The URL used could be "url" and if it is null or empty (before Chrome 88) use "domain" (which could be also empty because it is a host-only cookie) Reference: https://developer.chrome.com/docs/extensions/reference/cookies/#type-Cookie
                chrome.cookies.getAll({}, function (cookies) {
                    let allCookies = [];
                    console.log("@getCookies. Total cookies found: " + cookies.length);
                    if (details.url != null) {
                        for (let cookie of cookies) {
                            if (!cookie.domain.includes('chrome-extension')) {
                                try {
                                    let domain = (cookie.domain.startsWith(".") ? cookie.domain.substr(1) : cookie.domain).toLowerCase();
                                    if (details.url.toLowerCase().includes(domain)) {
                                        //allCookies.push({url: cookie.domain + cookie.path, name: cookie.name, value: cookie.value});
                                        allCookies.push(cookie.domain + '|' + cookie.name + '|' + cookie.value);
                                    }
                                } catch (e) {
                                    console.error('#Error getting cookie', cookie);
                                }
                            }
                        }
                    }
                    sendDatataMain(details, allCookies);
                })
            } else {
                sendDatataMain(details, null);
            }

        } catch (e) {
            console.error('SendInfoToAssDesktop: Error sending data to Assistant Desktop...', e);
        }
    // }
    return false;
}

function sendInfoToAssDesktopByPort(port, details) {
    var url = details.url;
    if (port) {
        console.log("sendInfoToAssDesktopByPort: Sending 'BodyContent' to Assistant Desktop...", url, 'Body length', bodyLength);
        var body = details.body;
        var bodyLength = details.body ? details.body.length : 0;
        var method = details.method;
        var headers = details.headers ? details.headers : '';
        port.postMessage({
            Type: 'BodyContent', Details: {
                url: url,
                body: body,
                method: method,
                headers: headers,
                contentUpdated: false
            }
        });
    } else {
        console.log("sendInfoToAssDesktopByPort: Sending 'BodyContent' (NO PORT)' to Assistant Desktop...", url, 'Body length', bodyLength);
        sendInfoToAssDesktop(details);
    }
}

function sendInfoToAssDesktopByMessage(chrome_runtime, details) {
    //if (isAllowedSourceByUrl(details.url)) {
        var url = details.url;
        var body = details.body;
        var bodyLength = details.body ? details.body.length : 0;
        var method = details.method;
        var headers = details.headers ? details.headers : '';
        console.log("sendInfoToAssDesktopByMessage: Sending 'BodyContent' to Assistant Desktop...", url, 'Body length', bodyLength);
        sendMessage(chrome_runtime, {
            Type: 'BodyContent', Details: {
                url: url,
                body: body,
                method: method,
                headers: headers,
                contentUpdated: true
            }
        });
    //}
}

function sendMessage(chrome_runtime, data) {
    chrome_runtime.sendMessage(data, function (response) {
        console.log("Response: ", response);
    })
}

function isInternalUsageUrl(url) {
    return !url || url.startsWith("chrome-extension://")  || url.startsWith("chrome://") || url.startsWith("devtools://") || url.includes("INFO_FROM_CHROME_DESKTOP");
}

function isAllowedResourceByUrl(url) {
    var _upperUrl = url ? url.toUpperCase() : '';
    return _upperUrl.includes(".WOFF") || _upperUrl.includes('/CSS?') || _upperUrl.includes(".SVG") || _upperUrl.includes(".WOFF2") || _upperUrl.includes(".TTF") || _upperUrl.includes('.PNG') || _upperUrl.includes('.JPG') || _upperUrl.includes('.JPEG') || _upperUrl.includes('.GIF') || _upperUrl.includes('.BMP') || _upperUrl.includes(".ICO") || _upperUrl.includes('.CSS');
}

function isAllowedSourceByUrl(url, content) {
    var _url = url ? url : 'null';
    var _upperUrl = _url.toUpperCase();

    // Filters everywhere
    if (isInternalUsageUrl(url)) {
        // console.log('Source (details):', port, details)
        return false;
    } else if (isAllowedResourceByUrl(_upperUrl) || _upperUrl.includes('.JS') || _upperUrl.includes('GOOGLEAPIS') || _upperUrl.includes("ADVERTISING.") || _upperUrl.includes("GOOGLEADS.") || _upperUrl.includes("ANALYTICS.") || _upperUrl.includes("GOOGLESYNDICATION") || _upperUrl.includes("/ADSERVE.") || _upperUrl.includes(".DOUBLECLICK.")) {
        // console.log('NOT Source (BodyContent no right resource):', port, url);
        return false;
    }

    if (_upperUrl.includes(".HTML") || _upperUrl.includes(".HTM") || _upperUrl.includes(".PHP") || _upperUrl.includes(".JSP") || _upperUrl.includes(".ASP") || _upperUrl.includes(".ASPX")) {
        return true;

    } else {
        /*var lastPart = "";
        try {
            var parts = _upperUrl.split('/');
            if (parts && parts.length > 0) {
                lastPart = parts[parts.length - 1];
            }
        } catch (e) {}
        if (!lastPart.includes(".")) {
            return true;
        } else {
            return false;	//TODO Maybe it should be true
        }*/
        if (content) {
            try {
                var _result = content ? (Array.isArray(content) ? content.join("|") : content) : 'null';
                var _upperResult = _result.toUpperCase();
                return (_upperResult.includes("<HTML") || _upperResult.includes("<BODY") || _upperResult.includes("<HEAD"));
            } catch (e) {
                return true;	// An error must not avoid using this file
            }
        } else {
            return true;	// Undetermined file by name
        }
    }
}

function removeAllCookies(callback) {
    chrome.cookies.getAll({}, function (cookies) {
        var total = 0;
        for (var i = 0; i < cookies.length; i++) {
            for (var protocol of ['https://', 'http://', 'file://', 'ws://', 'wss://', '']) {
                try {
                    chrome.cookies.remove({url: protocol + cookies[i].domain + cookies[i].path, name: cookies[i].name});
                    total++;
                } catch (e) {
                }
            }
        }
        if (total > 0) {
            console.warn(total + ' cookies removed');
        } else {
            console.log('No cookies to remove');
        }
        if (callback) {
            callback();
        }
    });
}

console.log('Common loaded');

function btoaFUS(str) {
    return btoa(fillUpto4(str, ' '));
}

function fillUpto4(str, filledChar) {
    if (!str || str.length == 0) {
        return str;
    } else {
        let neededChars = 4 - str.length % 4;
        if (neededChars > 0 && neededChars < 4) {
            for (let i = 1; i <= neededChars; i++) {
                str += filledChar
            }
        }
        return str;
    }
}

//TODO initial interval = 0 and after that the one by parameter sent
function watchMainCallerParams(callback, interval = 1000) {
    function _check() {
        //TODO Change document.cookie for window.cookieStore.get/set https://wicg.github.io/cookie-store/
        let cookie = document.cookie;
        if (cookie !== lastCookie) {
            try {
                let _callerParams = null;
                try {
                    _callerParams = JSON.parse(cookie.split(";").find(item => item.startsWith("callerParams=")).split("callerParams=")[1]);
                } catch (e) {}
                callback({oldCookieValue: lastCookie, newCookieValue: cookie, callerParams: _callerParams});
            } finally {
                lastCookie = cookie;
            }
        }
    }

    let lastCookie = null;  // document.cookie;
    _check();
    setInterval(()=> {
        _check();
    }, interval);
}

var jsCodeCountdown = [null, null, null];
function cancelAllJsCodeCountdown() {
    for (let index = 0; index <= 2; index++) {
        cancelJsCodeCountdown(index);
    }
}

function cancelJsCodeCountdown(index) {
    try {
        if (jsCodeCountdown[index]) {
            clearTimeout(jsCodeCountdown[index]);
        }
    } catch (e) {}
}

function sendJsCode(index, resultJsCode, url, countDown) {
    console.log('Alfa Extension Webserver: Sending resultJsCode in countdown: ' + countDown + ' ms');
    cancelJsCodeCountdown(index);
    jsCodeCountdown[index] = setTimeout(() => {
        cancelJsCodeCountdown(index);
        console.log('Alfa Extension Webserver: Countdown finished for JsCode, sending to Desktop Assistant');
        sendInfoToAssDesktop({
            url: url,
            body: resultJsCode
        });
    }, countDown);
}

function checkCookieTargetFound(paramReturnWhenCookieNameFound, url) {
    try {
        if (paramReturnWhenCookieNameFound != null && paramReturnWhenCookieNameFound.length() > 0 && url) {
            let pars = StringUtils.split(paramReturnWhenCookieNameFound, "|");
            for (let i = 0; i < pars.length; i += 2) {
                if (url.startsWith(pars[0])) {
                    let cookies = document.cookies.toUpperCase().split(";");
                    if (cookies.contains(pars[i + 1].toUpperCase() + "=")) {
                        console.debug("Cookie '" + pars[i + 1] + "' found at '" + pars[i]);

                        sendInfoToAssDesktop({
                            url: pars[0],
                            targetCookieFound: true
                        })

                        return pars[i];
                    }
                }
            }
        }
    } catch (e) {
        console.error("##Error processing isCookieTargetFound with string: " + (paramReturnWhenCookieNameFound != null ? paramReturnWhenCookieNameFound : "(null)"), e);
    }
    return null;
}

alfaAssistantAndroidPI = {};
alfaAssistantAndroidPI.sendKey = (keycode) => {
        console.log('TODO sendKey', keycode);
}
alfaAssistantAndroidPI.getMainURL = (keycode) => {
    console.log('TODO sendKey', keycode);
    return "TODO getMainURL";
}
