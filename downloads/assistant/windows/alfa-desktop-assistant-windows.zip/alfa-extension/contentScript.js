console.log('##Extension ' + chrome.runtime.id + ' activated! ContentScript at ', document.location.href, document.cookie);

const FORCE_GET_MORE_SOURCE = false;

//Disable console.clear()
console.clear = () => {}

var callerParams = {};
watchMainCallerParams(({oldCookieValue, newCookieValue, _callerParams})=> {
    if (callerParams) {
        checkCookieTargetFound(callerParams.returnWhenCookieNameFound, document.location.href);
    }

    if (_callerParams) {
        callerParams = _callerParams;

        try {
            console.warn('Alfa Extension Webserver: new callerParam just landed', callerParams);

            // Load new window url
            if (!callerParams.urlParamDEBUG) {
                // Stop console output
                disableConsole();
            }

            cancelAllJsCodeCountdown();

            checkCookieTargetFound(callerParams.returnWhenCookieNameFound, document.location.href);

            var jsCodeIndex = 0;
            // Mobile Assistant function called "getResultFromJsCode"
            if (callerParams.urlParamURL == url && callerParams.urlParamJSCode) {
                const jsCode = "(function() { " + callerParams.urlParamJSCode + " })();";
                let resultJsCode = "JSCODE: Unknown error?";
                try {
                    resultJsCode = eval(jsCode);
                } catch (e) {
                    resultJsCode = "JSCODE: Unknown error?";
                }
                const url = 'javascript:jscode';
                sendJsCode(jsCodeIndex, resultJsCode, url, callerParams.urlParamExtraPostDelay);
                jsCodeIndex++;
                callerParams.urlParamJSCode = null; // reset param to avoid use it again
            }

            // Mobile Assistant function called "launchDirectCodeJavascriptNeedDummyWait" and also "launchDirectCodeJavascriptNeedDummyWait"
            if (callerParams.urlParamURL == url && (callerParams.urlParamJSDirectCode || callerParams.urlParamJSDirectCode2)) {
                let arr = [];
                if (callerParams.urlParamJSDirectCode) {
                    arr.push(callerParams.urlParamJSDirectCode);
                }
                if (callerParams.urlParamJSDirectCode2) {
                    arr.push(callerParams.urlParamJSDirectCode2);
                }
                var i = callerParams.urlParamJSCode ? 1 : 0;
                for (let _jsCode of arr) {
                    setTimeout(() => {
                        const jsCode = "javascript: ((() => {       try { " + _jsCode + " } catch (launchDirectJavascriptError) { console.error('#Got a LaunchDirectJavascriptError: ' + launchDirectJavascriptError); };      }))();";
                        let resultJsCode = "JSCODE: Unknown error?";
                        try {
                            resultJsCode = eval(jsCode);
                        } catch (e) {
                            resultJsCode = "JSCODE: Unknown error?";
                        }
                        const url = 'javascript:jscode';
                        sendJsCode(jsCodeIndex, resultJsCode, url, callerParams.urlParamExtraPostDelay);
                        jsCodeIndex++;
                    }, 500 * i)
                    i++;
                }
                callerParams.urlParamJSDirectCode = null; // reset param to avoid use it again
                callerParams.urlParamJSDirectCode2 = null; // reset param to avoid use it again
            }
        } catch (e) {
            console.error('ERROR: Alfa Extension Webserver: issue getting callerParam:', newCookieValue, 'Error:', e);
        }
    //} else {
    //    callerParams = {};
    }
}, 500);

// onLoad event capture
window.addEventListener('load', webLoaded, false);
function webLoaded(evt) {
    console.warn(new Date().getTime() + 'Loaded status', document.location.href, evt)
    checkForDOM();
}

function isServerWaaw(str) {
    return false;   //TODO WAAW DISABLED BY ME

    if (str != null) {
        var url = str.toLowerCase();
        return (
            url.includes('https://waaw.tv') || url.includes('https://netu.tv') || url.includes('https://hqq.tv')
            ||
            url.includes('http://waaw.tv') || url.includes('http://netu.tv') || url.includes('http://hqq.tv')
        ) && (
            url.includes('player') || url.includes('watch_video')		//Not mandatory
        );
    } else {
        return false;
    }
}

// function interceptData() {
//     var xhrOverrideScript = document.createElement('script');
//     xhrOverrideScript.type = 'text/javascript';
//     xhrOverrideScript.innerHTML = `
//   (function() {
//     var XHR = XMLHttpRequest.prototype;
//     var send = XHR.send;
//     var open = XHR.open;
//
//     XHR.open = function(method, url) {
//         this.url = url; // the request url
//         return open.apply(this, arguments);
//     };
//
//     XHR.send = function() {
//         this.addEventListener('load', function() {
//             if (this.url.includes('google')) {
//                 console.log('##Content 1##');
//
//                 var dataDOMElement = document.createElement('div');
//                 dataDOMElement.id = 'interceptedDataFromCS';
//                 dataDOMElement.innerText = this.response;
//                 dataDOMElement.style.height = 0;
//                 dataDOMElement.style.overflow = 'hidden';
//                 document.body.appendChild(dataDOMElement);
//
//                 console.log('##Content 2##');
//
//                 /*var event = document.createEvent('Event');
//                 event.initEvent('commFromSource');
//                 document.dispatchEvent(event);*/
//
//                if (document && document.body) {
//                 document.body.style.backgroundColor = '#00ff01';
//                }
//
//                 console.log('##Content 9##');
//             }
//         });
//         return send.apply(this, arguments);
//     };
//   })();
//   `
//
//     document.head.prepend(xhrOverrideScript);
// }

function sendMessageLoadBody() {
    // console.log('Source (BodyContent):', window.location.href);
    // var method = null;  //TODO !!!
    // var headers = null;	//TODO !!!
    // sendMessage({Type: 'BodyContent', Details: { url: window.location.href, body: document.documentElement.innerHTML, method: method, headers: headers}});	// headerFromChrome: url, dataFromChrome: body

    //TODO Finished web loading

    setTimeout(() => {
        sendInfoToAssDesktopByMessage(chrome.runtime, {
            url: window.location.href,
            body: document.documentElement.innerHTML,
            method: '',  //TODO
            headers: '',  //TODO
            contentUpdated: false
        });
    }, 0)
}

function checkForDOM() {
    if (document.body) {    // && document.head
        sendMessageLoadBody();

        //interceptData();
        if (isServerWaaw(window.location.href)) {
            var vjsModalDialogContent = null;
            try {
                vjsModalDialogContent = $(".vjs-modal-dialog-content");
            } catch (e) {};
            sendMessage(chrome.runtime, {
                url: window.location.href,
                //source: document.documentElement
                source: document.documentElement.innerHTML + '|' + document.documentElement.outerHTML,
                vjsModalDialogContent: vjsModalDialogContent
            });
        }
    } else {
        requestIdleCallback(checkForDOM);
    }
}
if (FORCE_GET_MORE_SOURCE) {
    requestIdleCallback(checkForDOM);
}

/*
document.addEventListener("commFromSource", function(data) {
    chrome.runtime.sendMessage(data);
})*/

// if (chrome != null && chrome.tabs != null) {
//     console.log(chrome.tabs);
//     chrome.tabs.create({url: "chrome://extensions/?id=" + chrome.runtime.id});
//     console.log(chrome.runtime.id + ' hecho');
// }

// chrome.runtime.onConnect.addListener(function(port) {
// 	console.log('##BK - Extension added Listener onConnect for port ', port);
// 	port.onMessage.addListener(function (Message) {
// 		console.log('##BK - Extension trigered Listener onMessage for message', Message);
// 	})
// })
