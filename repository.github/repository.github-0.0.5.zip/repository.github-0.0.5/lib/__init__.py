import sys
import os
import xbmcvfs
import xbmc
import xbmcaddon

PY3 = False
if sys.version_info[0] >= 3: PY3 = True

def translatePath(path):

    if not path:
        return ''

    if PY3:
        if isinstance(path, bytes):
            path = path.decode('utf-8')
        path = xbmcvfs.translatePath(path)
        if isinstance(path, bytes):
            path = path.decode('utf-8')
    else:
        path = xbmc.translatePath(path)
        
    return path


__settings__ = xbmcaddon.Addon(id="repository.github")
sys.path.append(os.path.join(translatePath(__settings__.getAddonInfo('Path')), "lib"))