from lib.entries import run

run()
