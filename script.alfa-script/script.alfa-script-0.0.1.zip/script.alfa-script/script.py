# -*- coding: utf-8 -*-
import os
import re
import shutil

import xbmc
import xbmcaddon
import xbmcgui

PLUGIN_NAME = "alfa"
# PLUGIN_NAME = "pelisalacarta"

__settings__ = xbmcaddon.Addon(id="plugin.video." + PLUGIN_NAME)

data = ""

try:
    # do a backup
    path_settings = os.path.join(xbmc.translatePath(__settings__.getAddonInfo('Profile')), "settings.xml")
    path_settings_backup = os.path.join(xbmc.translatePath(__settings__.getAddonInfo('Profile')), "settings.backup.xml")
    shutil.copy(path_settings, path_settings_backup)

    # path_settings2 = os.path.join(xbmc.translatePath(__settings__.getAddonInfo('Profile')), "settings_new.xml")

    # open file
    f = open(path_settings, "r")
    # copy = open(path_settings2, "w")
    xbmc.log("              ---", xbmc.LOGNOTICE)
    xbmc.log("              --- 1", xbmc.LOGNOTICE)
    xbmc.log("              --- 2", xbmc.LOGNOTICE)
    xbmc.log("              --- 3", xbmc.LOGNOTICE)
    data = ""

    for line in f:
        matches = re.findall('<setting id="([^"]*)" value="([^"]*)', line, re.DOTALL)
        xbmc.log("macthes %s" % matches, xbmc.LOGNOTICE)
        if not matches:
            xbmc.log("no matches", xbmc.LOGNOTICE)
            # for <settings></settings> tag
            data += line
        else:
            xbmc.log("Matches", xbmc.LOGNOTICE)
            for _id, value in matches:
                xbmc.log("  dentro del for", xbmc.LOGNOTICE)
                xbmc.log("  _id:%s value:%s" % (_id, value), xbmc.LOGNOTICE)
                if _id != "adult_pin":
                    xbmc.log("    linea %s" % line, xbmc.LOGNOTICE)
                    xbmc.log("     value %s" % value, xbmc.LOGNOTICE)
                    if value:
                        # xbmc.log("    type value!! %s" % type(value), xbmc.LOGNOTICE)
                        xbmc.log("     antes value!! %s" % value, xbmc.LOGNOTICE)
                        value = value.replace("(str, &apos;", "")
                        value = value.replace("&apos;)", "")
                        xbmc.log("     despues value!! %s" % value, xbmc.LOGNOTICE)

                    aux_line = '<setting id="%s" value="%s" />\n' % (_id, value)
                    xbmc.log("    aux_line %s" % aux_line, xbmc.LOGNOTICE)
                    data += "    " + aux_line
    f.close()

    copy_file = open(path_settings, "w")
    copy_file.write(data)
    copy_file.close()

    xbmcgui.Dialog().ok("Alfa", "Conversión realizada")

except Exception, ex:
    template = "An exception of type %s occured. Arguments:\n%r"
    message = template % (type(ex).__name__, ex.args)
    xbmc.log(message, xbmc.LOGERROR)
    xbmcgui.Dialog().ok("Alfa", "Error, en conversión")
    xbmc.log("Datos a guardar %s" % data, xbmc.LOGERROR)
