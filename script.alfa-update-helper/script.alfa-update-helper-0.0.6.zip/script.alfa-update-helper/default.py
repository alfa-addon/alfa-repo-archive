# -*- coding: utf-8 -*-
# -*- Update Helper -*-
# -*- Created for Alfa-addon -*-
# -*- By the Alfa Develop Group -*-

import sys
PY3 = False
if sys.version_info[0] >= 3: PY3 = True; unicode = str; unichr = chr; long = int

import xbmc
import xbmcgui
import xbmcaddon
import os
import re
import json
import requests
import shutil
import traceback
import xbmcvfs
from zipfile import ZipFile
import xmltodict
from threading import Thread

result = True

if PY3:
    addons_path = xbmcvfs.translatePath("special://home/addons")
    if isinstance(addons_path, bytes):
        addons_path = addons_path.decode('utf-8')
else:
    addons_path = xbmc.translatePath("special://home/addons")

addonid = "plugin.video.alfa"
scriptid = "script.alfa-update-helper"

sys.path.append(os.path.join(addons_path, scriptid))
import logger

try:
    installed = bool(xbmc.getCondVisibility("System.HasAddon(%s)" % addonid))
    installed_version = xbmc.getInfoLabel('System.AddonVersion(%s)' % addonid)
except:
    installed = False
    installed_version = '0.0.0'
installed_path = os.path.join(addons_path, "%s" % addonid)
pkg_path = os.path.join(addons_path, "packages")

base_url = ["https://github.com/alfa-addon/alfa-repo/raw/master/plugin.video.alfa/", \
            "https://gitlab.com/addon-alfa/alfa-repo/-/raw/master/plugin.video.alfa/"]
try:
    xml = xmltodict.parse(requests.get("%s%s" % (base_url[1], "addon.xml")).content)
    available_version = xml["addon"]["@version"]
except:
    available_version = installed_version
updated_filename = "%s-%s.zip" % (addonid, available_version)
pkg_updated = os.path.join(pkg_path, updated_filename)
heading = "Alfa Update Helper"
progress = 0
auto_update = xbmcaddon.Addon(scriptid).getSetting("auto_update")


def clean_packages():
    logger.info()
    
    for pkg_name in os.listdir(pkg_path):
        if addonid in pkg_name or scriptid in pkg_name or "script.module.html5lib" in pkg_name:
            try:
                if os.path.exists(os.path.join(pkg_path, pkg_name)):
                    os.remove(os.path.join(pkg_path, pkg_name))
                    logger.info("%s has been deleted" % (pkg_name))
            except Exception as e:
                logger.error("*** Error deleting package %s: %s" % (pkg_name, str(e)))
                return False
    return True


def check_dependencies():
    logger.info()

    dependencies = ['script.module.html5lib', 'script.module.beautifulsoup4']
    
    for dependency in dependencies:
        found = bool(xbmc.getCondVisibility("System.hasAddon(%s)" % dependency))
        if not found:
            try:
                xbmc.executebuiltin('InstallAddon(%s)' % dependency)
                timeout = 30
                logger.info("Installing dependencie %s..." % dependency)
                while not found and timeout > 0:
                    xbmc.sleep(1000)
                    found = bool(xbmc.getCondVisibility("System.hasAddon(%s)" % dependency))
                    timeout -= 1
                if timeout == 0:
                    logger.error("*** Error Installing dependency %s..." % dependency)
                    raise Exception("Failed to install dependency")
    
            except:
                return False
        xbmc.sleep(3000)

    return True


def get_zip(info, retry=False, github=False):
    logger.info('retry=%s; github=%s' % (retry, github))
    
    global result
    
    for url in base_url:
        if github and 'github' not in url:                                      # Opción de verificación de Github
            continue
        logger.info("Downloading from: %s%s" % (url, updated_filename))
        
        try:
            reponse = requests.get("%s%s" % (url, updated_filename))
        except:
            reponse = requests.Response()
            reponse.status_code == 666
            logger.error(traceback.format_exc(1))
        if reponse.status_code == 200:
            zip_data = reponse.content
            result = False
            with open(pkg_updated, "wb") as f:
                f.write(zip_data)
            result = True
            break
        else:
            result = False
            logger.error("*** Error %s downloading... %s%s" % (str(reponse.status_code), url, updated_filename))
    
    else:
        result = False
        if not github:
            if info: info.update(progress, heading, "Error irrecuperable en la descarga, reintentalo más tarde...")
            logger.error("*** Unrecoverable downloading error, try later...")
            raise Exception("Unrecoverable downloading error, try later...")


def backup_and_remove():
    logger.info()
    
    backup_path = os.path.join(addons_path, "temp", addonid)
    if os.path.exists(backup_path):
        shutil.rmtree(backup_path, ignore_errors=True)
        xbmc.sleep(3000)

    if not os.path.exists(backup_path) and os.path.exists(installed_path):
        shutil.copytree(installed_path, backup_path)
        xbmc.sleep(3000)
        shutil.rmtree(installed_path, ignore_errors=True)
        xbmc.sleep(3000)
    else:
        if os.path.exists(os.path.join(installed_path, 'custom_code.json')):
            os.remove(os.path.join(installed_path, 'custom_code.json'))
        if os.path.exists(os.path.join(installed_path, 'last_fix.json')):
            os.remove(os.path.join(installed_path, 'last_fix.json'))
        logger.error("*** backing and removing installed version FAILED ...")
        
        
def restoring_backup():
    logger.info()
    
    backup_path = os.path.join(addons_path, "temp", addonid)
    if os.path.exists(backup_path):
        shutil.copytree(backup_path, installed_path)
        xbmc.sleep(3000)
    else:
        logger.error("*** Restoring installed version FAILED ...")


def extract_and_install(info):
    logger.info()

    if not os.path.exists(pkg_updated):
        get_zip(info)
    if os.path.exists(pkg_updated):
        try:
            with ZipFile(pkg_updated, "r") as zf:
                zf.extractall(addons_path)
            xbmc.sleep(5000)
        except:
            logger.info("*** ERROR Extracting version from ZipFile...")
            try:
                xbmc.executebuiltin('Extract("%s", "%s")' % (pkg_updated, addons_path))
                xbmc.sleep(5000)
            except:
                logger.error("*** Extracting version FAILED ...")
                logger.error(traceback.format_exc())
                return False
    else:
        if info: info.update(0, heading, "Error en la Extracción/Instalación de Alfa")
        logger.error("*** Missing package .zip file ...")
        return False

    if os.path.exists(installed_path):
        xbmc.executebuiltin('UpdateLocalAddons')
        xbmc.sleep(2000)
        method = "Addons.SetAddonEnabled"
        xbmc.executeJSONRPC(
            '{"jsonrpc": "2.0", "id":1, "method": "%s", "params": {"addonid": "%s", "enabled": true}}' % (method, addonid))
        return True
    
    if info: info.update(0, heading, "Error en la Extracción/Instalación de Alfa")
    logger.error("*** Add-on folder does not EXISTS ...")
    return False


def run(auto=False):
    logger.info('auto=%s' % auto)

    global result, progress

    info = xbmcgui.DialogProgressBG()
    info.create(heading, "")
    try:
        if auto:
            try:
                dialog = xbmcgui.Dialog()
                message = "[COLOR hotpink][B]Se ha detectado la nueva versión de Alfa %s. " % available_version
                message += "Déjanos que la instalemos por ti...[/B][/COLOR]"
                dialog.notification(heading, message, xbmcgui.NOTIFICATION_WARNING, 10000, True)
            except:
                logger.error(traceback.format_exc())

        info.update(progress, heading, "Limpiando paquetes antiguos...")
        clean_packages()
        xbmc.sleep(3000)
        info.update(progress, heading, "Verificando Dependencias")
        if check_dependencies():
            progress += 25
            info.update(progress, heading, "Descargando última versión...")
            get_zip(info)
            if installed:
                progress += 25
                info.update(progress, heading, "Creando copia de seguridad...")
                backup_and_remove()
            else:
                progress += 50
            info.update(progress, heading, "Actualizando...")
            if extract_and_install(info):
                progress += 25
                xbmc.sleep(1000)
                info.update(100, heading, "Se completó el proceso")
                logger.info("Se completó el proceso")
                result = True
            else:
                restoring_backup()
                raise Exception("Failed to install addon")

        else:
            raise Exception("Failed to install dependency")
    except:
        info.update(0, heading, "Ha ocurrido un error, no se pudo actualizar")
        result = False
        logger.error("*** Unrecoverable error while updating..." )
        logger.error(traceback.format_exc())
    
    xbmc.sleep(3000)
    info.close()

    if result:
        profile = json.loads(xbmc.executeJSONRPC('{"jsonrpc": "2.0", "id":1, "method": "Profiles.GetCurrentProfile"}'))
        logger.info("Reloading Profile...")
        user = profile["result"]["label"]
        xbmc.executebuiltin('LoadProfile(%s)' % user)
        #xbmc.executebuiltin('RunPlugin(plugin://plugin.video.alfa/videolibrary_service.py)')


def force_corrupted_zip():
    logger.info()
    
    # Tries to overload GitLab so there are chances to get corrupted downloaded .zips.  TO BE USED ONLY FOR TESTING
    def download_zip(url, i):
        try:
            reponse = requests.get("%s%s" % (url, updated_filename))
        except:
            reponse = requests.Response()
            reponse.status_code == 666
            logger.error(traceback.format_exc(1))
        info.update(progress + i, heading, "Lanzando nueva descarga .zip ...")
        if reponse.status_code == 200:
            zip_data = reponse.content
            zip_name = pkg_updated.replace('.zip', '_' + str(i+1) + '.zip')
            with open(zip_name, "wb") as f:
                f.write(zip_data)
            

            logger.info('Verifying new .zip download: %s...' % str(i+1))
            ret = None
            try:
                with ZipFile(zip_name, "r") as zf:
                    ret = zf.testzip()
            except Exception as e:
                ret = str(e)
            xbmc.sleep(1000)
            if ret is not None:
                logger.error("*** Corrupted .zip found %s, error %s..." % (zip_name, str(ret)))
                info.update(progress + i, heading, "Descarga .zip CORRUPTA...")
                os.rename(zip_name, zip_name.replace('.zip', '_CORRUPTED.zip'))
    
    global result, heading, info, progress
    
    info = xbmcgui.DialogProgressBG()
    info.create(heading, "")
    progress = 1

    threads_list = []
    url = base_url[1]
    x = 100                                                                     # Defines number of concurrent downloads to stress web
    info.update(0, heading, "Proceso de descarga masiva de %s .zip's comenzado ..." % str(x))
    logger.info("Proceso de descarga masiva de %s .zip's comenzado ..." % str(x))
    
    for i in range(x):
        z = Thread(target=download_zip, args=(url, i))
        z.setDaemon = True
        z.start()
        threads_list.append(z)

    while [thread_x for thread_x in threads_list if thread_x.isAlive()]:
        xbmc.sleep(5000)
        continue
    info.update(100, heading, "Proceso de descarga masiva de %s .zip's terminado ..." % str(x))
    logger.info("Proceso de descarga masiva de %s .zip's terminado ..." % str(x))
    xbmc.sleep(5000)
    info.close()


def monitor_update():
    
    global xml, available_version, updated_filename, pkg_updated, installed_version, result, installed
    
    newer = False

    # Alfa installed version
    try:
        installed = bool(xbmc.getCondVisibility("System.HasAddon(%s)" % addonid))
        if installed:
            installed_version = xbmc.getInfoLabel('System.AddonVersion(%s)' % addonid)
            __settings__ = xbmcaddon.Addon(id="%s" % addonid)
    except:
        installed = False

    if not installed:
        return False

    if PY3:
        existing_version = os.path.exists(xbmcvfs.translatePath("special://masterprofile/addon_data/%s/" % addonid))
        if isinstance(existing_version, bytes):
            existing_version = existing_version.decode('utf-8')
    else:
        existing_version = os.path.exists(xbmc.translatePath("special://masterprofile/addon_data/%s/" % addonid))
    
    # GitLab Repo version
    try:
        xml = xmltodict.parse(requests.get("%s%s" % (base_url[1], "addon.xml")).content)
        available_version = xml["addon"]["@version"]
    except:
        available_version = installed_version
        logger.error(traceback.format_exc(1))
        
    try:
        installed_version_list = installed_version.split('.')
        available_version_list = available_version.split('.')
        for i, ver in enumerate(available_version_list):
            if int(ver) > int(installed_version_list[i]):
                newer = True
                break
            if int(ver) < int(installed_version_list[i]):
                break
    except:
        newer = False
        logger.error(traceback.format_exc(1))
    
    # Pointing to the new version
    updated_filename = "%s-%s.zip" % (addonid, available_version)
    pkg_updated = os.path.join(pkg_path, updated_filename)
    
    # if different installed version to Repo, update
    logger.info("*** GitLab version: %s - Installed version: %s - Existing version: %s" % \
                (str(available_version), str(installed_version), str(existing_version)))
    if newer and existing_version and available_version != installed_version:
        
        # Verify that there is NO access to Github. If there is access, let Kodi do the normal update
        result = False
        get_zip('', retry=True, github=True)
        if result:
            logger.info('Github available. Let Kodi update...')
        else:
            xbmc.sleep(1000)
            for x in range (5):
                if clean_packages():
                    logger.info("*** Update to Alfa version %s starts..." % str(available_version))
                    xbmc.sleep(5000)
                    run(auto=True)
                    break
                xbmc.sleep(5000)
            

def monitor_run():
    global auto_update
    
    logger.info('Starting monitor. Auto_update [%s]...' % str(auto_update))
    num_version = xbmc.getInfoLabel('System.BuildVersion')
    num_version = float(re.match("\d+\.\d+", num_version).group(0))
    if num_version >= 14:
        monitor = xbmc.Monitor()                                                # For Kodi >= 14
    else:
        monitor = None                                                          # For Kodi < 14

    if monitor:
        monitor.waitForAbort(60)                                                # Let Kodi initializes
        while not monitor.abortRequested():
            if auto_update != xbmcaddon.Addon(scriptid).getSetting("auto_update"):
                auto_update = xbmcaddon.Addon(scriptid).getSetting("auto_update")
                logger.info('Auto_update ha cambiado a [%s]' % str(auto_update))
            if auto_update == 'true':
                monitor_update()
            if monitor.waitForAbort(3600):                                      # Every 1 hour
                break
    else:
        while not xbmc.abortRequested:
            xbmc.sleep(60000)
            break
        while not xbmc.abortRequested:
            if auto_update != xbmcaddon.Addon(scriptid).getSetting("auto_update"):
                auto_update = xbmcaddon.Addon(scriptid).getSetting("auto_update")
                logger.info('Auto_update ha cambiado a [%s]' % str(auto_update))
            if auto_update == 'true':
                monitor_update()
            xbmc.sleep(3600000)
    

if sys.argv[0] == "":
    monitor_run()
else:
    logger.info("Update to Alfa version %s starts..." % (str(available_version)))
    t = Thread(target=run)
    #t = Thread(target=force_corrupted_zip)                                      # Replace for run() when wanting to force corrupted .zips
    t.setDaemon = True
    t.start()
    t.join()

if not result:
    logger.error("Failed...")